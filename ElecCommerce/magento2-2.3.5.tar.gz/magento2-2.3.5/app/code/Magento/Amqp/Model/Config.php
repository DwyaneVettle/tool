<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Amqp\Model;

/**
 * {@inheritdoc}
 *
 * @deprecated 100.2.0
 */
class Config extends \Magento\Framework\Amqp\Config
{

}
